# music-share

This is the README for music-share by juvenile-orca

`npm install` to download dependencies

To run the app in development mode:

`npm run serve` to run locally
  
To run the app in production mode:

`npm run serve:prod` to run locally in production mode (without webpack middleware)
