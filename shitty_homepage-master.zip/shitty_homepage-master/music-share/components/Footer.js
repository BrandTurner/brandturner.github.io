import React, { Component } from 'react'

class Footer extends Component {

  render() {
    return (
      <footer>
        <span>&copy; 2015 songlink | <a href="mailto:songlinkapp@gmail.com">contact</a></span>
      </footer>
    )
  }

}

export default Footer
