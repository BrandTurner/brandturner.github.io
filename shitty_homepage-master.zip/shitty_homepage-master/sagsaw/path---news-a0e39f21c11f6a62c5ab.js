webpackJsonp([0xbdf5ef12e5c5],{485:function(e,t){e.exports={pathContext:{}}}});
//# sourceMappingURL=path---news-a0e39f21c11f6a62c5ab.js.map